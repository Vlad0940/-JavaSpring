create table person
(
    id       serial
        primary key,
    login    varchar(100),
    password varchar(255),
    role     varchar(255)
);

alter table person
    owner to postgres;

create table category
(
    id   serial
        primary key,
    name varchar(255)
);

alter table category
    owner to postgres;

create table product
(
    id          serial
        primary key,
    date_time   timestamp(6),
    description text         not null,
    price       real         not null
        constraint product_price_check
            check (price >= (1)::double precision),
    seller      varchar(255) not null,
    title       text         not null
        constraint uk_qka6vxqdy1dprtqnx9trdd47c
            unique,
    warehouse   varchar(255) not null,
    category_id integer      not null
        constraint fk1mtsbur82frn64de7balymq9s
            references category
);

alter table product
    owner to postgres;

create table image
(
    id         serial
        primary key,
    file_name  varchar(255),
    product_id integer not null
        constraint fkgpextbyee3uk9u6o2381m7ft1
            references product
);

alter table image
    owner to postgres;

create table product_cart
(
    id         serial
        primary key,
    person_id  integer
        constraint fksgnkc1ko2i1o9yr2p63ysq3rn
            references person,
    product_id integer
        constraint fkhpnrxdy3jhujameyod08ilvvw
            references product
);

alter table product_cart
    owner to postgres;

create table orders
(
    id           serial
        primary key,
    count        integer not null,
    date_time    timestamp(6),
    number       varchar(255),
    price        real    not null,
    status_order smallint,
    person_id    integer not null
        constraint fk1b0m4muwx1t377w9if3w6wwqn
            references person,
    product_id   integer not null
        constraint fk787ibr3guwp6xobrpbofnv7le
            references product
);

alter table orders
    owner to postgres;

